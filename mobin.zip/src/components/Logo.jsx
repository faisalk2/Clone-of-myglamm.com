import React from 'react'

export const Logo = () => {
  return (
    <div >
        <img width='60%' src='https://files.myglamm.com/site-images/original/MyGlamm-Logo_1.jpg' />
   </div>
  )
}
