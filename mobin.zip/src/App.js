
import './App.css';

import AllRoutes from './pages/AllRoutes';
import Payment from './pages/Payment';

function App() {
  return (
    <div className="App">
      <AllRoutes/>
    </div>
  );
}

export default App;
