import { Box, Image } from '@chakra-ui/react'
import React from 'react'

const NotFound = () => {
  return (
    <Box>
        <Image width={"100%"} height="750px" src='https://cdn.dribbble.com/users/3512533/screenshots/14168376/web_1280___8_4x.jpg'></Image>
    </Box>
  )
}

export default NotFound